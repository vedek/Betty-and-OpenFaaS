## OpenFaaS Documentation

The OpenFaaS documentation site is available at [docs.openfaas.com](https://docs.openfaas.com/)

