# Deployment guide for Kubernetes

This page has moved to the official documentation site:

https://docs.openfaas.com/deployment/kubernetes/
