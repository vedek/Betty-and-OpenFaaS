This page has moved to the docs site:

https://docs.openfaas.com/deployment/troubleshooting/

