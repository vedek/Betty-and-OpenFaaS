## Notes on load-testing or performance testing

This page has [moved to the OpenFaaS docs](https://docs.openfaas.com/architecture/performance/).
