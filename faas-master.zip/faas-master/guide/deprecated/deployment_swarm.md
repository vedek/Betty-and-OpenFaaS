# Deployment guide for Docker Swarm

This page has moved to the official documentation site:

https://docs.openfaas.com/deployment/docker-swarm/
