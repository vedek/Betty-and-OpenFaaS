#!/bin/sh

echo "Building functions/base:cobol"
docker build -t functions/base:cobol .
