#!/bin/sh

echo "Building functions/base:coffeescript-1.12-alpine"
docker build -t functions/base:coffeescript-1.12-alpine .

