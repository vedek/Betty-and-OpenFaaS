#!/bin/sh

echo "Building functions/base:python-2.7-alpine"
docker build -t functions/base:python-2.7-alpine .

