#!/usr/bin/env ruby

# $use_tree=true
$use_tree=false
$verbose=false
# $verbose=true

require_relative '../parser_test_helper'

class NumberTest  < ParserBaseTest

  include ParserTestHelper

  def test_type1
    puts parse "class of 1"
    assert_equals @result,Fixnum
    parse "class of 3.3"
    assert @result==Float
  end

  def test_type2
    assert "3.2 is a Numeric"
    assert "3.2 is a Float"
    assert "3.2 is a float"
    assert "3.2 is a real"
    assert "3.2 is a float number"
    assert "3.2 is a real number"
    # assert "3.2 is not an integer"
  end

  def test_type3
    # assert_equal 1,2
    assert "3 is a Number"
    assert "3 is a Fixnum"
    assert "3 is a Numeric"
    assert "3 is a Integer"
  end

  def test_english_number_types
    # todo !
    assert "3.2 is a number"
    assert "3.2 is a real number"
    assert "3.2 is a real"
    assert "3.2 is a float"
    assert "3.2 is a float number"
    assert "3 is a number"
    assert "3 is a integer"
    assert "3 is an integer"
  end

  def _test_int_methods
    parse "invert 3"
    assert @result=="1/3"
  end

  def test_parse_float

    init "5.0"
    x=@parser.real

    # parse "5.0"
    # assert_equals result,5

    # init "20/5.0"
    # x=@parser.algebra
    # p x
    parse "20/5.0"
    assert_equals result,4
  end


  def current
    # test_failing
    test_type1
    # test_type2
    # test_type3
  end

end
