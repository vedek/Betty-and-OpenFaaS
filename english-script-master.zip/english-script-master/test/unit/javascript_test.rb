#!/usr/bin/env ruby
$use_tree=false
$verbose=false
# $verbose=true

require_relative '../parser_test_helper'

class JavascriptTestParser < ParserBaseTest

  include ParserTestHelper

  def test_hash

  end
end
