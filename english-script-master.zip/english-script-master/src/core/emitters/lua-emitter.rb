# lua is NATIVE micro vm used by gaming industry, also Lua.NET
