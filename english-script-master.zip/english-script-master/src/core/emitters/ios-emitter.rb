# free RETIRED:( MOBIRUBY https://github.com/mobiruby/mobiruby-ios

# $200/year: RubyMotion PLEASE become open source!!
# OH: https://github.com/HipByte/RubyMotion
RubyMotion is a commercial toolchain for iOS, OS X and Android development using the Ruby programming language.
This repository contains the parts of the RubyMotion product that are opensource. It does not contain the full product,

# APPCELERATOR Write in JavaScript, run native on any device and OS

# python ok'ish lol no
