namespace org.pannous.esine{

    public class Extensions{
    }

}
