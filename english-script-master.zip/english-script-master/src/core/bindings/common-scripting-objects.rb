def  mail
    {sender:'me',
    recipients:['a','b'],
    address:{
        name:"bla",
        email:"a@b.com"
    }
    }
end
