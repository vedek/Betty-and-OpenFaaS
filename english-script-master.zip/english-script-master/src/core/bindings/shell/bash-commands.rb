$bash_commands=%w[cat ls rm awk grep gcc less more cd cron wc vi vim uptime
addgroup
adduser
alias
apache2ctl
apt-get
logrotate
apt-internal-solver
aptitude
bash
bg
bzip2
cat
chgrp
chmod
chown
chpasswd
chroot
chrt
cksum
cut
curl
#column
crontab
cpan
du
df
dd
diff
diff3
dpkg
disown
dmesg
echo
ed
eject
fg
finger
fsck
git
gettext
gpg
grep
groupadd
groupdel
groupmod
groups
grpck
grpconv
grpunconv
#grub-install
gunzip
gzip
hexdump
history
hostname
htpasswd
iconv
ifconfig
initctl
iptables
java
jobs
joe
killall
keytool

ldd
lsof

md5sum
mkfs
mount
mv
nano
netcat
nc
nice
nohup
python
python2
python3
ping
printenv
pppd
ps
pstree
pwd
popd
pushd

renice
rsync
ssh-keygen
ssh
scp
sudo
sudovim
su
tee
telnet
tcpdump
tr
tracepath
traceroute
tty
ulimit
umask
umount
unalias
uname
uniq
unlink
unzip
updatedb
uptime
useradd
usermod
users
vi
vim
wc
wget
whatis
whereis
whiptail
whoami
whois
whoopsie


yacc
zless
zmore
znew
zprint
zsh
zcat
zcmp
zdiff
zdump
zfgrep
zgrep
zip
]
# NOT:
# kill
# make
# find
# cd ?
# time
# which
# while
# who
# xargs later

# p $bash_commands_auto
