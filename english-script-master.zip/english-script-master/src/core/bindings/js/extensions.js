String.prototype.reverse=function(){}
