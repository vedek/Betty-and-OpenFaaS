node=new Node("mail",
    new Node("subject","hi"),
    new Node("recipients","a","b"),
//    new Node("recipients",new Node("a"),new Node("b")),
    new Node("sender",
        new Node("name","bla"),
        new Node("email","a@b.com")
    )
);
