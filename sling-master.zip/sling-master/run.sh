#!/bin/sh

python3 python/run.py $*

